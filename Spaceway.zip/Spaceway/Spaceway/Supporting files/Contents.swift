//
//  Contents.swift
//  Spaceway
//
//  Created by Matteo Melloni on 19/10/2019.
//  Copyright © 2019 Matteo Melloni. All rights reserved.
//

import Foundation

let PLANET_TITLES = ["Sole", "1"]
let SUBTITLES = ["Il sole è caldo", "1"]
let DESCRIPTIONS = ["Il Sole (dal latino: Sol) è la stella madre del sistema solare,[6] attorno alla quale orbitano gli otto pianeti principali (tra cui la Terra), i pianeti nani, i loro satelliti, innumerevoli altri corpi minori e la polvere diffusa per lo spazio, che forma il mezzo interplanetario. La massa del Sole, che ammonta a circa 2 × 1030 kg,[2] rappresenta da sola il 99,86% della massa complessiva del sistema solare.", "1"]
